class CreateUsers < ActiveRecord::Migration[5.1]
  def change
    create_table :users do |t|
      t.string :username, null: false

      # timestamps adds created_at and updated_at columns for us
      t.timestamps
    end

    # Adding indices is how we enforce uniqueness on the DB level
    # Adding indices also speeds up lookup time for DB fields, but it
    # is an expensive operation.
    add_index :users, :username, unique: true
  end
end
