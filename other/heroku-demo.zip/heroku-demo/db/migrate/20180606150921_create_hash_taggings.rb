class CreateHashTaggings < ActiveRecord::Migration[5.1]
  def change
    create_table :hash_taggings do |t|
      t.integer :hash_tag_id, null: false
      t.integer :tweet_id, null: false

      t.timestamps
    end

    add_index :hash_taggings, :tweet_id
    add_index :hash_taggings, :hash_tag_id
  end
end
