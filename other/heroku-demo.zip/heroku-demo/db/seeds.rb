# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)


# Mashu: Mozzarella
# Oscar: Asiago
# Brian: Brie
# Matthias: Swiss
# Maurice: Pep J
# Abby: Feta

User.destroy_all
Tweet.destroy_all
HashTag.destroy_all
HashTagging.destroy_all

puts "Creating Users..."
# notice that we're supplying *passwords*, not *password digests*
# we'll need to create a password setter and getter that saves the password digest instead
# these User objects will eventually be garbage-collected because there will no longer be a reference
# remember that there's no persistence between request/response cycles!
# users will send up the password in plaintext to log in/sign up, so theoretically it could be caught mid-stream
# HTTPS is excellent protection against this, and if you don't use it you're wrong
# look it up! :)
mashu = User.create!(username: "Mashu-rella", password: "hunter12")
oscar = User.create!(username: "Osc-iago", password: "hunter12")
abby = User.create!(username: "Feta!", password: "hunter12")
maurice = User.create!(username: "Peppa-J", password: "hunter12")
matthias = User.create!(username: "Mr. Swiss", password: "hunter12")
brian = User.create!(username: "Brie-an", password: "hunter12")

puts "Creating Tweets..."

tweet1 = Tweet.create!(body: "I love Disney songs!", author_id: mashu.id)
tweet2 = Tweet.create!(body: "Moana is my favorite", author_id: mashu.id)
tweet3 = Tweet.create!(body: "What's today's spanish lesson?", author_id: mashu.id)

tweet4 = Tweet.create!(body: "If you try to do a rollback, you're gonna have a bad time.", author_id: oscar.id)
tweet5 = Tweet.create!(body: "Mighty Quinn's?", author_id: oscar.id)
tweet6 = Tweet.create!(body: "Let's go climbing!", author_id: oscar.id)

tweet7 = Tweet.create!(body: "West coast, best coast", author_id: abby.id)
tweet8 = Tweet.create!(body: "My new rooftop is lit.", author_id: abby.id)
tweet9 = Tweet.create!(body: "Elephants are great", author_id: abby.id)

tweet10 = Tweet.create!(body: "Kanye's new album: enough said.", author_id: maurice.id)
tweet11 = Tweet.create!(body: "I <3 SQL", author_id: maurice.id)
tweet12 = Tweet.create!(body: "What're you watching on Netflix?", author_id: maurice.id)

tweet13 = Tweet.create!(body: "Mechanical keyboards are superior.", author_id: matthias.id)
tweet14 = Tweet.create!(body: "Andor is now available on the play store!", author_id: matthias.id)
tweet15 = Tweet.create!(body: "Javascript is my favorite language", author_id: matthias.id)

tweet16 = Tweet.create!(body: "I love the circus!", author_id: brian.id)
tweet17 = Tweet.create!(body: "No one codes like Gaston", author_id: brian.id)
tweet18 = Tweet.create!(body: "Rockstar energy drinks > coffee", author_id: brian.id)

puts "Creating Hastags..."

ht1 = HashTag.create!(name: "#disney")
ht2 = HashTag.create!(name: "#musicaltheater")
ht3 = HashTag.create!(name: "#kanye")
ht4 = HashTag.create!(name: "#programing")
ht5 = HashTag.create!(name: "#appacademy")
ht6 = HashTag.create!(name: "#california")
ht7 = HashTag.create!(name: "#BBQ")

puts "Creating Hastaggings..."

htg1 = HashTagging.create!(hash_tag_id: ht1.id, tweet_id: tweet1.id)
htg2 = HashTagging.create!(hash_tag_id: ht1.id, tweet_id: tweet2.id)
htg3 = HashTagging.create!(hash_tag_id: ht4.id, tweet_id: tweet4.id)
htg4 = HashTagging.create!(hash_tag_id: ht7.id, tweet_id: tweet5.id)
htg5 = HashTagging.create!(hash_tag_id: ht6.id, tweet_id: tweet7.id)
htg6 = HashTagging.create!(hash_tag_id: ht5.id, tweet_id: tweet4.id)
htg7 = HashTagging.create!(hash_tag_id: ht5.id, tweet_id: tweet9.id)
htg8 = HashTagging.create!(hash_tag_id: ht3.id, tweet_id: tweet10.id)
htg9 = HashTagging.create!(hash_tag_id: ht4.id, tweet_id: tweet11.id)
htg10 = HashTagging.create!(hash_tag_id: ht5.id, tweet_id: tweet11.id)
htg11 = HashTagging.create!(hash_tag_id: ht4.id, tweet_id: tweet13.id)
htg12 = HashTagging.create!(hash_tag_id: ht4.id, tweet_id: tweet14.id)
htg13 = HashTagging.create!(hash_tag_id: ht4.id, tweet_id: tweet15.id)
htg14 = HashTagging.create!(hash_tag_id: ht5.id, tweet_id: tweet15.id)
htg14 = HashTagging.create!(hash_tag_id: ht1.id, tweet_id: tweet17.id)
htg14 = HashTagging.create!(hash_tag_id: ht2.id, tweet_id: tweet17.id)
htg14 = HashTagging.create!(hash_tag_id: ht4.id, tweet_id: tweet17.id)
htg14 = HashTagging.create!(hash_tag_id: ht5.id, tweet_id: tweet18.id)

puts "Done!"
