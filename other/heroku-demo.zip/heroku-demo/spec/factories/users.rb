FactoryBot.define do
  factory :user do
    username { Faker::FamilyGuy.character } # because this is in a block, the code in the block will get run each time we make a new factory
    password "starwars" # all the user factories will have this password, since it's not in a block
  end
end
