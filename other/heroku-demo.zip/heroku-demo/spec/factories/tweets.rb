FactoryBot.define do
  factory :tweet do
    body { Faker::ChuckNorris.fact }
    association :author, factory: :user # association is the name of the association defined on the tweet, and factory is the name of the factory that we've defined
  end
end
