require 'rails_helper'

# capybara uses feature/scenario instead of describe/it
# our capybara specs should simulate navigating around our website

feature 'creating a tweet', type: :feature do
  before :each do
    user = create(:user) # like creating a user thru rails c; doesnt log them in
    log_in_user(user)
    visit(new_tweet_url)
  end

  scenario 'takes a body' do
    # page is a variable capy-b gives us, refers to the current page we're on
    # have content checks that the text is anywhere on the page; doesnt check any specific html element
    expect(page).to have_content("New Tweet")
    expect(page).to have_content("Body")
  end

  scenario 'takes us back to the tweet#show' do
    make_tweet("It's tweet-a-licious")
    # this should send the post request and then redirect. but we're not testing those details here, because lower-level unit tests should take care of that
    # in end-to-end tests, we're just testing user experience
    expect(page).to have_content("One single tweet")
    expect(page).to have_content("It's tweet-a-licious")
  end



end


feature 'deleting a tweet', type: :feature do
  before :each do
    user = create(:user)
    log_in_user(user)
    make_tweet("capybara is so fun!")
    click_button("Delete this Tweet")
  end

  scenario 'deletes a tweet' do
    save_and_open_page # this method is from the launchy gem. opens the browser to show us what capy-b sees at this exact point in time
    expect(page).not_to have_content("to be deleted")
    expect(page).to have_content("All the Tweets")
    expect(current_path).to eq("/tweets")
  end
end
