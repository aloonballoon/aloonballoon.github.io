require 'rails_helper'

RSpec.describe User, type: :model do
  it { should validate_presence_of(:username) }
  it { should validate_presence_of :session_token }
  it { should validate_presence_of :password_digest }
  it { should validate_length_of(:password).is_at_least(6) }

  it { should have_many :tweets }

  describe 'uniqueness' do
    before :each do
      # the things we insert into our test db only persist for the current describe block
      create(:user) #calls FactoryBot create method, and creates a user so we dont have to write that all out
      # create(:user)
    end

    it { should validate_uniqueness_of(:session_token) } # tries to insert something in the db with the same session_token as an already existing entry, and expects it to fail. So, there must already be at least one existing entry in our test db to test against
    it { should validate_uniqueness_of(:username) }
  end

  describe '#is_password?' do
    let!(:user) { create(:user) } #the ! ensures that the code in the block gets run immediately, vs waiting for when the user object is needed
    context 'with a valid password' do
      it 'should return true' do
        expect(user.is_password?('starwars')).to be true
      end
    end

    context 'with invalid password' do
      it 'should return false' do
        expect(user.is_password?('bananaman')).to be false
      end
    end
  end
end
