require 'rails_helper'

RSpec.describe TweetsController, type: :controller do
  describe 'GET to #index' do
    it 'renders the tweets index' do
      get(:index) #gem rails controller test gives us great helper methods
      expect(response).to render_template(:index)
    end
  end

  describe 'GET to #new' do
    it 'renders the new tweet page' do
      create(:user)
      #subject is implicitly the current instance of tweets controller
      # allow(subject).to receive(:current_user).and_return(User.last)
      allow(subject).to receive(:current_user) { User.last } # we're stubbing #current_user, bc this method shouldnt depend on that method working properly
      get :new # can omit parenthesis bc ruby is pretty
      expect(response).to render_template(:new)
    end
  end

  describe 'DELETE to #destroy' do
    # we dont test that the tweet actually gets destroyed; we're not testing the #destroy method
    # we just care that the controller creates the correct response w/ the given request
    let!(:test_tweet) { create(:tweet) }
    it 'destroys a tweet' do
      allow(subject).to receive(:current_user) { test_tweet.author }
      delete(:destroy, params: { id: test_tweet.id })
      # delete :destroy, params: { id: test_tweet.id }

      expect(response).to redirect_to(tweets_url)
      expect(response).to have_http_status(302)
    end
  end
end
