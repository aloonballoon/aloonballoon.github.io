Rails.application.routes.draw do
  # verb 'path', to: 'controller#action', as: 'url_helper'
  # get '/tweets', to: 'tweets#index', as: 'tweets'
  # get '/tweets/:id', to: 'tweets#show', as: 'tweet'
  # post '/tweets', to: 'tweets#create'

  # resources :tweets
  # root to: 'tweets#index'
  # resources :tweets
  # resource :session, only: [:new, :create, :destroy]
  # resources :users, only: [:new, :create]
  # note that this is *singular* resource (though the controller will still be plural)
  # there's only one session; we won't be specifying the id of a session
  # there's not even a sense of an id in this implementation, since there's no table/model
  # get '/set_cookie', to: 'tweets#set_cookie'
  # get '/get_cookie', to: 'tweets#get_cookie'

  # when we navigate to '/' we hit this controller action
  root to: 'static_pages#root'

  # we namespace the routes that return json specifically under api
  # all of these controller actions will return json.  We only need data now, not html
  # 'everything inside of this block should be organized under api'
  # these controllers will live under a directory of api
  namespace :api, defaults: { format: 'json' } do  # <-- responses by default should be json
    resources :tweets
    resources :users 
    resource :session
  end
end
