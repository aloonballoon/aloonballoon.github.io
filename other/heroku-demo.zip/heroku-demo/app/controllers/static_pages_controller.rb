# We created this file.  All it does is render the root view
# We need a controller to handle the request to root and serve out initial html
# By convention and for convenience we create this static_pages controller to render a root template for us.
# This is the only controller that will give us html
class StaticPagesController < ApplicationController
  def root
    render :root
  end
end
