class SessionsController < ApplicationController # PLURAL!
  def new # /session/new
    render :new # this line isn't strictly necessary
  end

  def create
    # find a user by their username and password
    user = User.find_by_credentials(
      params[:user][:username],
      params[:user][:password]
    )

    if user
      # log the user in
      # remember the definition of being logged in
      log_in!(user) # this method will come from ApplicationController
      # finish the response
      redirect_to tweets_url
    else
      # let them try again
      # make sure they know what they did wrong so they can fix it
      # supply an array because we want to iterate and don't have errors.full_messages
      flash.now[:errors] = ['Invalid username/password']
      render :new
    end
  end

  def destroy
    log_out! # this also comes from ApplicationController
    redirect_to new_session_url # take them to the log in page
  end
end
