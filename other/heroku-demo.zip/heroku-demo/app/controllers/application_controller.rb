class ApplicationController < ActionController::Base
  protect_from_forgery with: :exception
  # raise an error if someone messes with us
  # this is specifically protection against CSRF (cross site request forgery)
  # all your forms will need an auth token to show they're legit

  helper_method :current_user, :logged_in? # this gives us access to these methods in our views

  def log_in!(user)
    # remember the definition of being logged in
    # set the session token in the cookie to the session token of the user
    session[:session_token] = user.reset_session_token!
    # ABR - Always Be Resetting
    # reset on log in, reset on log out
    # extra safety to make sure no one can use the old token
  end

  def current_user
    # find the user whose token matches the token in the cookie we received in this request
    User.find_by(session_token: session[:session_token])
  end

  def logged_in?
    !!current_user # converts it to the opposite boolean, then converts it back to the right boolean
    # if current_user is nil, this will convert it to true, then false
    # if current_user is an object, it will convert it to false, then true
    # very common pattern for converting into booleans
  end

  def log_out!
    current_user.reset_session_token! # give the current user a new session token
    session[:session_token] = nil # clear it out of the cookie
  end

  def ensure_logged_in
    redirect_to new_session_url unless logged_in?
  end
end
