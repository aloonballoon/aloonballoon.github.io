class UsersController < ApplicationController
  def index
    render plain: "users index"
  end

  def show
    render plain: "users show"
  end

  def new
    @user = User.new # a dummy object so that we can pass a prefilled object from create if necessary
    render :new
  end

  def create
    @user = User.new(user_params)

    if @user.save # don't use `save!` here; it will stop execution of this method
      # if we could sign them up, log them in as well
      log_in!(@user)
      # flash[:notice] = ['Welcome back!']
      redirect_to tweets_url
    else
      # let them try again
      # tell them what they did wrong (i.e. show them their errors)
      # use the Flash(now), Luke!
      flash.now[:errors] = @user.errors.full_messages
      render :new
    end
  end

  private
  def user_params
    params.require(:user).permit(:username, :password)
  end
end

### FLASH ###
# flash is just a very short-term cookie

# flash vs flash.now:
# flash.now will put information into the flash object just for this response
# flash will put information into the flash object for this response,
  # as well as the NEXT req/res cycle
# RULE OF THUMB: use flash.now for render, use flash for redirect
# setting differentiates between flash and flash.now, getting is just flash
