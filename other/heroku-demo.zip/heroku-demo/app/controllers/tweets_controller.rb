class TweetsController < ApplicationController
  # intercept requests that would hit new/create/edit/update to make sure user is logged in
  # if a before_action triggers a render/redirect, it will not call the controller action
  # before_action :ensure_logged_in, only: [:new, :create, :edit, :update, :destroy]
  before_action :ensure_logged_in, except: [:index, :show]
  # consider also protecting against different users, not just whether a user is logged in

  def index
    # We use instance variable in the controller actions to have
    # access to them in the views
    @tweets = Tweet.all.includes(author: :tweets) # eager-load the author info of each tweet so that we dont need to keep querying the db when we later call tweet.author
    # render json: Tweet.all
    render :index
  end

  def show
    @tweet = Tweet.find(params[:id])
    # render json: tweet
    # rails controller actions assume you want to render the view
    # with the same name as the action (only if you follow the conventions)
    render :show
  end

  def new
    @tweet = Tweet.new
    render :new
  end

  def create
    # tweet = Tweet.new(body: 'This is sick', author_id: 4)
    # we only whitelist params when creating or updating a record
    tweet = Tweet.new(tweet_params)
    tweet.author_id = current_user.id
    # save inserts the record if there are no errors
    # it returns true if it worked, false if it didn't
    if tweet.save
      # when using redirect_to we must pass it a url, not the name of a template
      # use the url helper!
      # redirect_to is always a 'GET'
      redirect_to tweet_url(tweet) # rails knows to grab the id from the object
      # render :show
    else
      # render json: tweet.errors.full_messages, status: :unprocessable_entity
      flash[:errors] = tweet.errors.full_messages
      render :new, status: 422
    end
  end

  def edit
    @tweet = Tweet.find(params[:id])
    #render edit is the default!
  end

  def update
    tweet = Tweet.find(params[:id])
    if tweet.update(tweet_params)
      # render json: tweet
      redirect_to tweet_url(tweet)
    else
      render json: tweet.errors.full_messages, status: 422
    end
  end

  def destroy
    # we get auto 404 when we use can't find a record
    tweet = Tweet.find(params[:id])
    if tweet.author_id == current_user.id
      tweet.destroy
      redirect_to tweets_url
    else
      render plain: "you can't delete another person's tweets"
    end
    # render json: ["Tweet destroyed"]
  end

  def set_cookie
    # cookies persist data across request/response cycles
    # HTTP(<=1.1) is stateless; this is the primary method of persisting state across these connections
    maybe_cookie = params[:my_cookie] # was set to 'hello world'
    # cookies must be less than or equal to 4kb in size - they're pretty tiny
    # how many cookies can a browser store for a single domain? depends on the browser
    if maybe_cookie # truthy if we passed a param
      cookies[:my_cookie] = maybe_cookie # Rails provides us a `cookies` hash-like object
      render plain: "I am setting your cookie: #{maybe_cookie}"
    else
      render plain: 'You must provide a cookie'
    end
  end

  def get_cookie
    my_cookie = cookies[:my_cookie]
    if my_cookie
      render plain: "Here's your cookie: #{my_cookie}"
    else
      render plain: "You haven't set a cookie yet"
    end
  end

  private
  def tweet_params
    # mandates that there is a key of tweet in our params
    # then only allows body and author_id to be accepted
    # tweet[body] = "hey hey"
    # tweet[author_id] = 6
    params.require(:tweet).permit(:body)
  end
end
