# The classname must reflect api namespace

class Api::TweetsController < ApplicationController
  def index
    @tweets = Tweet.all.includes(author: :tweets)
    # render json: @tweets
    render :index
  end

  def show
    @tweet = Tweet.find(params[:id])
    render :show
  end

  def create
    @tweet = Tweet.new(tweet_params)
    @tweet.author = current_user
    # randomly assign user until frontend authentication

    if @tweet.save
      # render json: @tweet
      render :show
    else
      render json: @tweet.errors.full_messages, status: 422
    end
  end

  def tweet_params
    params.require(:tweet).permit(:body)
  end
end
