class Api::UsersController < ApplicationController
  def index
    @users = User.all.includes(:tweets)
    # render :index
  end

  def update
    @user = User.find(params[:id])
    if @user.update(user_params)
      render :show
    else
      render json: ['something went wrong'], status: 422
    end
  end
  
  def create 
    @user = User.new(user_params)
    if @user.save 
      log_in!(@user)
      render :show
    else 
      render json: @user.errors.full_messages, status: 422
    end
  end

  private
  def user_params
    params.require(:user).permit(:username, :password)
  end
end

### FLASH ###
# flash is just a very short-term cookie

# flash vs flash.now:
# flash.now will put information into the flash object just for this response
# flash will put information into the flash object for this response,
  # as well as the NEXT req/res cycle
# RULE OF THUMB: use flash.now for render, use flash for redirect
# setting differentiates between flash and flash.now, getting is just flash
