# == Schema Information
#
# Table name: tweets
#
#  id         :bigint(8)        not null, primary key
#  body       :string           not null
#  author_id  :integer          not null
#  created_at :datetime         not null
#  updated_at :datetime         not null
#

class Tweet < ApplicationRecord

  validates :body, presence: true

  # this validates for both presence (unless optional: true) AND existence
  # the user must exist with the author_id that the tweet is being created with
  belongs_to :author,
    foreign_key: :author_id,  # author_id of the tweet...(key in our own table)
    primary_key: :id, # matches the id... (this is the id from the Users table)
    class_name: :User # of a User object from the 'users' table

    # Use 'optional: true' if you want to side step the automatic validation
    # optional: true

  has_many :hash_taggings,
    foreign_key: :tweet_id,
    primary_key: :id,
    class_name: :HashTagging

  has_many :hash_tags,
    through: :hash_taggings, # this is a method on this class
    source: :hash_tag # this is the association on the 'through' class

end
