# == Schema Information
#
# Table name: hash_taggings
#
#  id          :bigint(8)        not null, primary key
#  hash_tag_id :integer          not null
#  tweet_id    :integer          not null
#  created_at  :datetime         not null
#  updated_at  :datetime         not null
#


# this represents a joins table!
class HashTagging < ApplicationRecord

  # when the foreign key is in our current table,
  # that denotes a belongs_to relationship
  belongs_to :hash_tag,
    primary_key: :id,
    foreign_key: :hash_tag_id,
    class_name: :HashTag

  belongs_to :tweet,
    primary_key: :id,
    foreign_key: :tweet_id,
    class_name: :Tweet

end
