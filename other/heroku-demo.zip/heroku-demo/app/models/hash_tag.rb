# this is what gem annotate gives us

# == Schema Information
#
# Table name: hash_tags
#
#  id         :bigint(8)        not null, primary key
#  name       :string           not null
#  created_at :datetime         not null
#  updated_at :datetime         not null
#

class HashTag < ApplicationRecord

  validates :name, presence: true, uniqueness: true

  has_many :hash_taggings,
    primary_key: :id,
    foreign_key: :hash_tag_id,
    class_name: :HashTagging

  has_many :tweets,
    through: :hash_taggings,
    source: :tweet

end
