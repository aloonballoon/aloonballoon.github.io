// This will return a promise!!!!

export const fetchTweets = () => {
  return $.ajax({
    url: '/api/tweets',
    method: 'GET'
  });
};

export const createTweet = tweet => {
  
  return $.ajax({
    url: '/api/tweets',
    method: 'POST',
    data: { tweet: tweet }
  });
};
