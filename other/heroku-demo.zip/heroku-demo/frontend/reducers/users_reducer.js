import { RECEIVE_USERS, RECEIVE_USER } from '../actions/user_actions';
import { RECEIVE_CURRENT_USER } from '../actions/session_actions';
import { RECEIVE_TWEET, RECEIVE_TWEETS } from '../actions/tweet_actions';
import { merge } from 'lodash';

export default (state = {}, action) => {
  Object.freeze(state);
  let newState = merge({}, state);
  switch (action.type) {
    case RECEIVE_USERS:
    case RECEIVE_TWEETS:
      // here we're fetching all users so we don't
      // care about overwriting old state
      return merge({}, state, action.users);
    case RECEIVE_USER:
    case RECEIVE_CURRENT_USER:
      // here we want to add action.user
      // to the entire slice of users state
      // first we make a copy of state to not mutate old state
      newState[action.user.id] = action.user;
      return newState;
    case RECEIVE_TWEET:
      // update the users array of tweet Ids?
      // newState[action.tweet.authorId].tweetIds.push(action.tweet.id);
      const tweetIds = newState[action.tweet.authorId].tweetIds;
      tweetIds.push(action.tweet.id);
      return newState;
    default:
      return state;
  }
};
