import users from './users_reducer';
import tweets from './tweets_reducer';
import { combineReducers } from 'redux';

export default combineReducers({
  tweets: tweets,
  users: users,
});
