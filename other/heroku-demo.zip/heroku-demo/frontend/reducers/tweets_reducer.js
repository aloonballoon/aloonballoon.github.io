import {
  RECEIVE_TWEETS,
  RECEIVE_TWEET
} from '../actions/tweet_actions';
import { RECEIVE_USERS } from '../actions/user_actions';
import { merge } from 'lodash';

export default (state = {}, action) => {
  switch (action.type) {
    case RECEIVE_TWEETS:
    case RECEIVE_USERS:
      // const newState = {};
      // action.tweets.forEach(tweet => {
      //   newState[tweet.id] = tweet;
      // });
      // return newState;
      return merge({}, state, action.tweets); // our goal
    case RECEIVE_TWEET:
      //
      const { tweet } = action;
      // Object.assign works like merge, but IS NOT the same
      return Object.assign({}, state, { [tweet.id]: tweet });
    default:
      return state;
  }
};
