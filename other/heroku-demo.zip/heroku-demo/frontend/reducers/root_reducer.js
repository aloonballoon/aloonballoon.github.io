import entities from './entities_reducer';
import session from './session_reducer';
import { combineReducers } from 'redux';


export default combineReducers({
  entities,
  session: session
});

// function combineReducers(options) {
//   return function(state, action) {
//     const newState = {};
//     Object.keys(options).forEach(slice => {
//       newState[slice] = options[slice](state[slice], action);
//     });
//     return newState;
//   };
// }
