import React, { Component } from 'react';
import { Redirect } from 'react-router-dom';

export default class SessionForm extends Component {
  constructor(props) {
    super(props);

    this.state = {
      username: '',
      password: ''
    };

    this.handleSubmit = this.handleSubmit.bind(this);
  }

  updateField(field) {
    return e => {
      this.setState({ [field]: e.currentTarget.value });
    };
  }

  handleSubmit(e) {
    e.preventDefault();
    this.props.formAction(Object.assign({}, this.state));
  }

  render() {
    return (
      <form onSubmit={this.handleSubmit}>
        <input type="text"
          value={this.state.username}
          onChange={this.updateField('username')}/>
        <input type="password"
          value={this.state.password}
          onChange={this.updateField('password')}/>
        <button>{this.props.buttonText}</button>
      </form>
    );
  }
}
