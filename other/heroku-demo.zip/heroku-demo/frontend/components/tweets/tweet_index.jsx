import React, { Component } from "react";
import { connect } from "react-redux";
import TweetForm from "./tweet_form";
import TweetIndexItem from './tweet_index_item';
import { getTweets } from "../../actions/tweet_actions";

class TweetIndex extends Component {
  componentDidMount() {
    this.props.getTweets();
  }

  render() {
    const tweets = this.props.tweets.map(tweet => {
      return (
        <TweetIndexItem tweet={tweet} key={tweet.id} />
      );
    });

    return (
      <main>
        <TweetForm />
        <h3>Tweets</h3>
        <ul>{tweets}</ul>
      </main>
    );
  }
}

const mapStateToProps = state => {
  const tweets = Object.values(state.entities.tweets);

  return {
    tweets
  };
};

const mapDispatchToProps = dispatch => {
  return {
    getTweets: () => dispatch(getTweets())
  };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(TweetIndex);
