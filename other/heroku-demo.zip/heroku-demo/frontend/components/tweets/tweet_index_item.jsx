import React from 'react';
import { connect } from 'react-redux';

function TweetIndexItem ({ tweet, user }) {
  return (
    <li>
      {tweet.body} - {user.username}
    </li>
  );
}

const mapStateToProps = (state, ownProps) => {
  const authorId = ownProps.tweet.authorId;
  const user = state.entities.users[authorId];

  return {
    user,
  };
};

export default connect(mapStateToProps)(TweetIndexItem);
