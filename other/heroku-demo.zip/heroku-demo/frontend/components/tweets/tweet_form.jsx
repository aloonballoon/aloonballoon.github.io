import React, { Component } from "react";
import { connect } from "react-redux";
import { createTweet } from "../../actions/tweet_actions";

class TweetForm extends Component {
  constructor(props) {
    super(props);
    this.state = { body: "" };
    this.submit = this.submit.bind(this);
  }

  handleChange(field) {
    // setState is a react method. It sets local component state and causes a rerender
    // It does not dispatch an action.
    return e => {
      this.setState({ [field]: e.target.value });
    };
  }

  submit(e) {
    e.preventDefault();
    this.props.createTweet(Object.assign({}, this.state));
  }

  render() {
    return (
      <form onSubmit={this.submit}>
        <label>Tweet a Tweet!</label>
        <input onChange={this.handleChange("body")} />

        <button>Create Tweet!</button>
      </form>
    );
  }
}

const mapDispatchToProps = dispatch => {
  return {
    createTweet: tweet => dispatch(createTweet(tweet))
  };
};

export default connect(
  null,
  mapDispatchToProps
)(TweetForm);
