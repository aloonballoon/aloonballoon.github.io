import React from 'react';
import { HashRouter, Route, NavLink } from 'react-router-dom';
import UserIndex from './users/user_index';
import TweetIndex from './tweets/tweet_index';
import { AuthRoute, ProtectedRoute } from '../util/route_util';
import { connect } from 'react-redux';
import LoginContainer from './session/login_container';
import SignupContainer from './session/signup_container';

import { logout } from '../actions/session_actions';

function App({ loggedIn, user, logout }) {
  return (
    <HashRouter>
      <div>
        <div id="tweeter"></div>
        {!loggedIn ?
          <div>
            <NavLink exact to="/signup">Signup</NavLink>
            <NavLink exact to="/login">Login</NavLink>
          </div>
          :
          <div>
            <h1>{user.username} 💩</h1>
            <button onClick={logout}>Get out</button>
            <NavLink exact to="/tweets">Tweets Index</NavLink>
            <NavLink exact to="/users">Users Index</NavLink>
          </div>
        }


        <AuthRoute exact component={SignupContainer} path="/signup" />
        <AuthRoute component={LoginContainer} path="/login" />
        <ProtectedRoute component={TweetIndex} path="/tweets" />
        <ProtectedRoute component={UserIndex} path="/users" />
      </div>
    </HashRouter>
  );
}

const mapStateToProps = state => {
  return {
    loggedIn: Boolean(state.session.id),
    user: state.entities.users[state.session.id]
  };
};

const mapDispatchToProps = dispatch => {
  return {
    logout: () => dispatch(logout())
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(App);
