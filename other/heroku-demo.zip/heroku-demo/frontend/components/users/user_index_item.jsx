import React from 'react';
import { Route, Link } from 'react-router-dom';
import { connect } from 'react-redux';

function UserIndexItem ({ user, tweets }) {
  return (
    <div>
      <h1>
        <Link to={`/users/${user.id}`}>{user.username}</Link>
        {tweets.map(tweet => {
          return <li key={tweet.id}>{tweet.body}</li>;
        })}
      </h1>
    </div>
  );
}

const mapStateToProps = (state, ownProps) => {
  const tweetIds = ownProps.user.tweetIds || [];
  const tweets = tweetIds.map(tweetId => {
    return state.entities.tweets[tweetId];
  });
  return {
    tweets: tweets,
  };
};

export default connect(mapStateToProps)(UserIndexItem);
