import React from "react";
import { connect } from "react-redux";
import { Route } from 'react-router-dom';
import { fetchUsers } from "../../actions/user_actions";
import UserIndexItem from "./user_index_item";
import UsernameUpdateForm from "./username_update_form";

class UserIndex extends React.Component {
  componentDidMount() {
    this.props.fetchUsers();
  }

  render() {
    const users = this.props.users.map(user => {
      return (
        <UserIndexItem key={user.id} user={user} />
      );
    });

    return (
      <div className="flex">
        <ul className="user-index">{users}</ul>
        <Route
          component={UsernameUpdateForm}
          path="/users/:userId" />
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    users: Object.values(state.entities.users)
  };
};

const mapDispatchToProps = dispatch => {
  return {
    fetchUsers: () => dispatch(fetchUsers())
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(UserIndex);
