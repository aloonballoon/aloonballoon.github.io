// This signature is necessary for custom middleware.  Don't sweat it.
// The dispatch we receive from the store is specific to that store.
const thunk = ({ dispatch, getState }) => next => action => {
  if (typeof action === 'function') {
    // just invoking the action
    return action(dispatch, getState);
  }
  // `next` will either be the next piece of middleware, or your reducers
  return next(action);
};

export default thunk;

// middleware signature, more info here:
// http://redux.js.org/docs/api/applyMiddleware.html
