import * as TweetApiUtil from '../util/tweet_api_util';

export const RECEIVE_TWEETS = 'RECEIVE_TWEETS';
export const RECEIVE_TWEET = 'RECEIVE_TWEET';

// Actions can now be pojos or functions

// POJO action creators
export const receiveTweets = ({ tweets, users }) => {
  return {
    type: RECEIVE_TWEETS,
    tweets,
    users,
  };
};

export const receiveTweet = tweet => {

  return {
    type: RECEIVE_TWEET,
    tweet,
  };
};

// FUNCTION action creators

// This is a function, but it still creates an action.
// This action however will be a function
export const getTweets = () => {
  // This is our action:
  // We cannot just import `dispatch` because dispatch
  // is tied to its' specific store.
  return dispatch => {
    // Make the ajax call that returns a promise with our tweets
    // The ajax call is how we talk to the backend
    return TweetApiUtil.fetchTweets().then(
      payload => dispatch(receiveTweets(payload))
    );
  };
};

export const createTweet = tweet => dispatch => {

  return TweetApiUtil.createTweet(tweet).then(
    tweet => dispatch(receiveTweet(tweet))
  );
};
