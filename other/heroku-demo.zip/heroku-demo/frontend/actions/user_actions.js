import * as UserApiUtil from "../util/user_api_util";

export const RECEIVE_USERS = "RECEIVE_USERS";
export const RECEIVE_USER = "RECEIVE_USER";

const receiveUsers = ({ users, tweets }) => {
  return {
    type: RECEIVE_USERS,
    users, // this is shortcut for users: users
    tweets,
  };
};

const receiveUser = user => {
  return {
    type: RECEIVE_USER,
    user
  };
};

export const fetchUsers = () => {
  return dispatch => {
    return UserApiUtil.fetchUsers().then(payload => {
      return dispatch(receiveUsers(payload));
    });
  };
};

export const updateUser = user => {
  return dispatch => {
    return UserApiUtil.updateUser(user).then(user => {
      return dispatch(receiveUser(user));
    });
  };
};
